package com.niit.connect;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Report
{
    int max;
    int paymentDates[];
    int status[];
    ConnectClass c=null;
    Connection con=null;
    public void generateReport(String rno)
    {
        paymentDates=new int[4];
        status=new int[3];
        
        try {
            Connection con=c.getConnection();
            
            c=ConnectClass.getInstance();
            con=c.getConnection();
            
            String query="select to_number(to_char(inst1Date,'dd')),to_number(to_char(inst2Date,'dd')),to_number(to_char(inst3Date,'dd')),to_number(to_char(inst4Date,'dd'))"+
             "from paymentactualdates where rno=?";
            
            PreparedStatement pstmt=con.prepareStatement(query);

            pstmt.setString(1,rno);
            ResultSet rs=pstmt.executeQuery();

            rs.next();
            for(int i=0;i<3;i++)
            {
                paymentDates[i]=rs.getInt(i+1);
                if(paymentDates[i]<=7)
                {
                    status[i]=0;
                }
                else if(paymentDates[i]>7 && paymentDates[i]<=10)
                {
                    status[i]=1;
                }
                else if(paymentDates[i]>10)
                {
                    status[i]=2;
                }
                
            }
            
      } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally
        {
        }
    }
    
    public int findStatus()
    {
        int result=maxRepeating(status,3,3);
        System.out.println("The max repeating element is "+result);
        
        return result;
    }
    
    static int maxRepeating(int arr[], int n, int k) 
    { 
        // Iterate though input array, for every element 
        // arr[i], increment arr[arr[i]%k] by k 
        for (int i = 0; i< n; i++) 
            arr[(arr[i]%k)] += k; 
  
        // Find index of the maximum repeating element 
        int max = arr[0], result = 0; 
        for (int i = 1; i < n; i++) 
        { 
            if (arr[i] > max) 
            { 
                max = arr[i]; 
                result = i; 
            } 
        } 
  
        /* Uncomment this code to get the original array back 
        for (int i = 0; i< n; i++) 
          arr[i] = arr[i]%k; */
  
        // Return index of the maximum element 
        return result; 
    } 
}

